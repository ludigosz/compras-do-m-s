# 🛒 Lista de Compras do Mês

Site único (HTML + CSS + JavaScript, sem dependências externas) para controlar suas compras de supermercado com orçamento automático — feito para uso prático durante as compras, direto do celular.

**Abra o `index.html` no navegador — não precisa de instalação, servidor ou internet.**

## Funcionalidades

- 💰 Orçamento do mês editável, com saldo restante calculado automaticamente
- 🛒 Total das compras somado em tempo real conforme você marca os itens
- ✅ Checkbox grande para marcar item como comprado (fácil de tocar no celular)
- ➕➖ Botões de +/− para ajustar quantidade sem precisar digitar
- 📊 Barra de progresso do orçamento + aviso automático quando o saldo fica baixo ou é ultrapassado
- 🔢 Contador "X de Y itens marcados", visível mesmo quando os preços ainda estão zerados
- 🔍 Busca por produto e ordenação (nome, menor preço, maior valor total)
- 🗂️ Filtros rápidos: Todos / Pendentes / Comprados
- 📝 Campo de observação por item (ex: marca preferida)
- 🔗 Botão **Compartilhar**: envia uma cópia da lista por WhatsApp/link (ou código) e permite importar a lista de outra pessoa. É um envio de cópia, não sincronização ao vivo
- 💾 Tudo salvo no `localStorage` do navegador — os dados continuam lá mesmo fechando o navegador ou reiniciando o computador
- 📱 Layout responsivo, testado em telas de celular de 320px a 390px de largura, sem cortes ou zoom indesejado

## Como usar no GitHub Pages

1. Suba este repositório no GitHub (o arquivo principal já se chama `index.html`, exigido pelo GitHub Pages).
2. Vá em **Settings → Pages**.
3. Em "Source", selecione a branch `main` e a pasta `/ (root)`.
4. Salve — o GitHub vai gerar um link público (algo como `https://seu-usuario.github.io/nome-do-repositorio/`).

## Compartilhar a lista

Os dados ficam salvos só no navegador de cada pessoa. Para outra pessoa ver a lista, use **Compartilhar → Enviar pelo WhatsApp** (ou Copiar link). Quem abrir o link escolhe se quer substituir a própria lista pela recebida. Quando você atualizar a lista, envie de novo.

## Privacidade

Nenhum dado sai do seu navegador, a não ser quando você mesmo envia o link/código para alguém.
